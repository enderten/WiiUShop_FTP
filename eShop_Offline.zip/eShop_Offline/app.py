from flask import Flask, render_template, request, jsonify
from ftplib import FTP
import os

app = Flask(__name__)

@app.route("/")
def home():
    # Lista todos los juegos en la carpeta 'static/games'
    games = [d for d in os.listdir('static/games') if os.path.isdir(os.path.join('static/games', d))]
    return render_template('index.html', games=games)

@app.route("/install", methods=["POST"])
def install():
    ip = request.form.get("wiiu_ip")
    game_name = request.form.get("game_name")
    
    local_game_path = f"static/games/{game_name}"
    target_dir = f"/fs/vol/external01/install/{game_name}"
    print(f"Conectando a {ip} y copiando a {target_dir}...")

    try:
        ftp = FTP(ip, timeout=20)
        ftp.login()
        try:
            ftp.mkd(target_dir)
        except Exception as e:
            print(f"Carpeta ya existe o error: {e}")

        def ftp_upload(path, ftp_conn, dest_dir):
            for item in os.listdir(path):
                full_path = os.path.join(path, item)
                if os.path.isfile(full_path):
                    print(f"Subiendo archivo: {full_path} --> {dest_dir}/{item}")
                    with open(full_path, 'rb') as file:
                        ftp_conn.storbinary(f'STOR {dest_dir}/{item}', file)
                else:
                    try:
                        ftp_conn.mkd(f'{dest_dir}/{item}')
                    except Exception as e:
                        print(f"Carpeta ya existe o error: {e}")
                    ftp_upload(full_path, ftp_conn, f'{dest_dir}/{item}')

        ftp_upload(local_game_path, ftp, target_dir)
        ftp.quit()

        return jsonify({"status": "success", "message": f"'{game_name}' enviado correctamente a la Wii U en {target_dir}."})

    except Exception as e:
        print(f"Error FTP: {e}")
        return jsonify({"status": "error", "message": str(e)})

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
