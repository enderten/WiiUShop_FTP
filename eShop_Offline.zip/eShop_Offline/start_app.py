import webview
import threading
import subprocess

def start_flask():
    subprocess.Popen(['python3', 'app.py'])

if __name__ == '__main__':
    # Inicia el server Flask en un hilo separado
    threading.Thread(target=start_flask, daemon=True).start()
    # Espera un poco para que Flask arranque
    import time
    time.sleep(2)
    # Abre la ventana nativa con pywebview
    webview.create_window('Wii U Offline Shop', 'http://127.0.0.1:5000', width=900, height=700)
